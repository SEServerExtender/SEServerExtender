var class_s_e_mod_a_p_i_1_1_a_p_i_1_1_definitions_1_1_cube_blocks_1_1_ore_detector_definition =
[
    [ "OreDetectorDefinition", "class_s_e_mod_a_p_i_1_1_a_p_i_1_1_definitions_1_1_cube_blocks_1_1_ore_detector_definition.html#a73ad4db9185c8f5657711862336e1d23", null ],
    [ "GetSubTypeDefinition", "class_s_e_mod_a_p_i_1_1_a_p_i_1_1_definitions_1_1_cube_blocks_1_1_ore_detector_definition.html#a3b40dd6fedbc85bb3f5e07bc40a14a1e", null ],
    [ "RequiredPowerInput", "class_s_e_mod_a_p_i_1_1_a_p_i_1_1_definitions_1_1_cube_blocks_1_1_ore_detector_definition.html#a0039f6aa57363a5c6100c3cba407d56a", null ]
];