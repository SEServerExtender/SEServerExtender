var class_s_e_mod_a_p_i_internal_1_1_a_p_i_1_1_common_1_1_power_manager =
[
    [ "PowerManager", "class_s_e_mod_a_p_i_internal_1_1_a_p_i_1_1_common_1_1_power_manager.html#a42a3f72615473c4774023fb31717d20d", null ],
    [ "RegisterPowerProducer", "class_s_e_mod_a_p_i_internal_1_1_a_p_i_1_1_common_1_1_power_manager.html#aafa86ac0a9950a97e87908a9c20d7833", null ],
    [ "RegisterPowerReceiver", "class_s_e_mod_a_p_i_internal_1_1_a_p_i_1_1_common_1_1_power_manager.html#ac40da6ab833e1caa465a2edc617d510c", null ],
    [ "UnregisterPowerProducer", "class_s_e_mod_a_p_i_internal_1_1_a_p_i_1_1_common_1_1_power_manager.html#a2d5db2adb78f1cfdf478e421c21afafb", null ],
    [ "UnregisterPowerReceiver", "class_s_e_mod_a_p_i_internal_1_1_a_p_i_1_1_common_1_1_power_manager.html#a959007b675eb1d3ae2a0e3a7a8fd8d05", null ],
    [ "m_powerManager", "class_s_e_mod_a_p_i_internal_1_1_a_p_i_1_1_common_1_1_power_manager.html#af0cb4066829eb215b0e97d7c9c3b2978", null ],
    [ "AvailablePower", "class_s_e_mod_a_p_i_internal_1_1_a_p_i_1_1_common_1_1_power_manager.html#a18db5c407dc800760ceb246c64f9aaef", null ],
    [ "TotalPower", "class_s_e_mod_a_p_i_internal_1_1_a_p_i_1_1_common_1_1_power_manager.html#a59ed1f347121358e3fa4922c4376ca2a", null ]
];