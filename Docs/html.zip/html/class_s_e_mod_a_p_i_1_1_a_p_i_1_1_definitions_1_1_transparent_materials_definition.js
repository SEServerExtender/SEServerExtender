var class_s_e_mod_a_p_i_1_1_a_p_i_1_1_definitions_1_1_transparent_materials_definition =
[
    [ "TransparentMaterialsDefinition", "class_s_e_mod_a_p_i_1_1_a_p_i_1_1_definitions_1_1_transparent_materials_definition.html#a0f119b6365a72d4b7a82d7331c5a8ef0", null ],
    [ "GetNameFrom", "class_s_e_mod_a_p_i_1_1_a_p_i_1_1_definitions_1_1_transparent_materials_definition.html#a07405dc40fa3ca76edc3e26af6d5bfde", null ],
    [ "AlphaMistingEnable", "class_s_e_mod_a_p_i_1_1_a_p_i_1_1_definitions_1_1_transparent_materials_definition.html#aa42e6d7dafd2de578a4e75cfe8a16e6a", null ],
    [ "CanBeAffectedByOtherLights", "class_s_e_mod_a_p_i_1_1_a_p_i_1_1_definitions_1_1_transparent_materials_definition.html#ae0a2bab098384a81fd540eaea9b34e51", null ],
    [ "Emissivity", "class_s_e_mod_a_p_i_1_1_a_p_i_1_1_definitions_1_1_transparent_materials_definition.html#a195eb6efa59c91e45aa13baabc0c2f6e", null ],
    [ "IgnoreDepth", "class_s_e_mod_a_p_i_1_1_a_p_i_1_1_definitions_1_1_transparent_materials_definition.html#a3d73a8a8a0738dd779c961dfa5b4bc50", null ],
    [ "Name", "class_s_e_mod_a_p_i_1_1_a_p_i_1_1_definitions_1_1_transparent_materials_definition.html#a5fd741929eca681f7751c337e6deffc5", null ],
    [ "SoftParticleDistanceScale", "class_s_e_mod_a_p_i_1_1_a_p_i_1_1_definitions_1_1_transparent_materials_definition.html#a36461eea8b021f858feac7ec81daa4cd", null ],
    [ "Texture", "class_s_e_mod_a_p_i_1_1_a_p_i_1_1_definitions_1_1_transparent_materials_definition.html#aa9fde3dc6c1712102d7d2f7eea9dc40c", null ],
    [ "UseAtlas", "class_s_e_mod_a_p_i_1_1_a_p_i_1_1_definitions_1_1_transparent_materials_definition.html#a796ac3b47e73c4218a744ef7065151a5", null ],
    [ "UVOffset", "class_s_e_mod_a_p_i_1_1_a_p_i_1_1_definitions_1_1_transparent_materials_definition.html#a076573a362c4d9bba0fa401a519e58fc", null ],
    [ "UVSize", "class_s_e_mod_a_p_i_1_1_a_p_i_1_1_definitions_1_1_transparent_materials_definition.html#ac9154960c0ae4f7063135bafa4d102d2", null ]
];