var class_s_e_mod_a_p_i_1_1_a_p_i_1_1_type_converters_1_1_vector3_i_type_converter =
[
    [ "CreateInstance", "class_s_e_mod_a_p_i_1_1_a_p_i_1_1_type_converters_1_1_vector3_i_type_converter.html#ac390f647377055895ce34f822ba70c8b", null ],
    [ "GetCreateInstanceSupported", "class_s_e_mod_a_p_i_1_1_a_p_i_1_1_type_converters_1_1_vector3_i_type_converter.html#ad8b9c37bfc62a74a09f08876009f19cd", null ]
];