var class_s_e_mod_a_p_i_internal_1_1_a_p_i_1_1_chat_1_1_chat_session_manager =
[
    [ "Sessions", "class_s_e_mod_a_p_i_internal_1_1_a_p_i_1_1_chat_1_1_chat_session_manager.html#a5e0ca6e5b0d79a11407ed488128f07b1", null ]
];