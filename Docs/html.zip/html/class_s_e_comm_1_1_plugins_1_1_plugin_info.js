var class_s_e_comm_1_1_plugins_1_1_plugin_info =
[
    [ "Id", "class_s_e_comm_1_1_plugins_1_1_plugin_info.html#ad618561e98b2be37c622eb052f2008e8", null ],
    [ "Name", "class_s_e_comm_1_1_plugins_1_1_plugin_info.html#a536f99983a62a58bd7417fdd90d648e3", null ],
    [ "Version", "class_s_e_comm_1_1_plugins_1_1_plugin_info.html#af40bf0845f10b12cd1ada59c7a4ac52f", null ]
];