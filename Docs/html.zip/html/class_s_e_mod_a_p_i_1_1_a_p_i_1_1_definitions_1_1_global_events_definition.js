var class_s_e_mod_a_p_i_1_1_a_p_i_1_1_definitions_1_1_global_events_definition =
[
    [ "GlobalEventsDefinition", "class_s_e_mod_a_p_i_1_1_a_p_i_1_1_definitions_1_1_global_events_definition.html#a86dc29a3e0fc40430cd500dbd1ca96ec", null ],
    [ "GetNameFrom", "class_s_e_mod_a_p_i_1_1_a_p_i_1_1_definitions_1_1_global_events_definition.html#a0104f6d1c92d47b5b60a0286ecfa54de", null ],
    [ "DisplayName", "class_s_e_mod_a_p_i_1_1_a_p_i_1_1_definitions_1_1_global_events_definition.html#a4f746995321e40c6397040ca99cb40d5", null ],
    [ "EventType", "class_s_e_mod_a_p_i_1_1_a_p_i_1_1_definitions_1_1_global_events_definition.html#a4535a315c997a7d455abcc44985937bb", null ],
    [ "FirstActivation", "class_s_e_mod_a_p_i_1_1_a_p_i_1_1_definitions_1_1_global_events_definition.html#a24cb9529968563c222b0f52eef07a3fa", null ],
    [ "MaxActivation", "class_s_e_mod_a_p_i_1_1_a_p_i_1_1_definitions_1_1_global_events_definition.html#a3ec4c82064578614bf0aabccaa0a3e1c", null ],
    [ "MinActivation", "class_s_e_mod_a_p_i_1_1_a_p_i_1_1_definitions_1_1_global_events_definition.html#a36da757509cea22fd2921054d0aad2a3", null ]
];