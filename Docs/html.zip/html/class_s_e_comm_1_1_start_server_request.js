var class_s_e_comm_1_1_start_server_request =
[
    [ "ConfigurationName", "class_s_e_comm_1_1_start_server_request.html#a31e93b4b33cc247992c18a71166e135a", null ],
    [ "ProtocolVersion", "class_s_e_comm_1_1_start_server_request.html#a7b184a1d2270c1b9f4521620c3a6fb07", null ]
];