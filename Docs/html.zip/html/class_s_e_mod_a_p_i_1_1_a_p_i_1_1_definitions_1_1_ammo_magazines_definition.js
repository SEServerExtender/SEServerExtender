var class_s_e_mod_a_p_i_1_1_a_p_i_1_1_definitions_1_1_ammo_magazines_definition =
[
    [ "AmmoMagazinesDefinition", "class_s_e_mod_a_p_i_1_1_a_p_i_1_1_definitions_1_1_ammo_magazines_definition.html#a19ad7b408e456fa5e95cf631efffed30", null ],
    [ "GetNameFrom", "class_s_e_mod_a_p_i_1_1_a_p_i_1_1_definitions_1_1_ammo_magazines_definition.html#ae5c9a12e8445c2abb2d2be7d5979d590", null ],
    [ "Caliber", "class_s_e_mod_a_p_i_1_1_a_p_i_1_1_definitions_1_1_ammo_magazines_definition.html#a2f9bd9893541dcb5a00e4759c54aad9d", null ],
    [ "Capacity", "class_s_e_mod_a_p_i_1_1_a_p_i_1_1_definitions_1_1_ammo_magazines_definition.html#acd7560e12d76f68f58f30d02883a701c", null ],
    [ "DisplayName", "class_s_e_mod_a_p_i_1_1_a_p_i_1_1_definitions_1_1_ammo_magazines_definition.html#ae2ae6b2a337d853328ce549599d50461", null ],
    [ "Icon", "class_s_e_mod_a_p_i_1_1_a_p_i_1_1_definitions_1_1_ammo_magazines_definition.html#ace8ddcf84466c7f190c590fd0e0197c8", null ],
    [ "Mass", "class_s_e_mod_a_p_i_1_1_a_p_i_1_1_definitions_1_1_ammo_magazines_definition.html#a8d23a0593174c75b8cd235f8da3e9d20", null ],
    [ "Model", "class_s_e_mod_a_p_i_1_1_a_p_i_1_1_definitions_1_1_ammo_magazines_definition.html#a8345c1f57fed2a1956cc453168334930", null ],
    [ "Size", "class_s_e_mod_a_p_i_1_1_a_p_i_1_1_definitions_1_1_ammo_magazines_definition.html#adb710c143307bf76f4bac445eb695c28", null ],
    [ "Volume", "class_s_e_mod_a_p_i_1_1_a_p_i_1_1_definitions_1_1_ammo_magazines_definition.html#a09ddb61157d6ef4227c7aedcf4a99e02", null ]
];