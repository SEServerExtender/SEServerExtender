var class_s_e_mod_a_p_i_extensions_1_1_a_p_i_1_1_session_manager =
[
    [ "SessionManager", "class_s_e_mod_a_p_i_extensions_1_1_a_p_i_1_1_session_manager.html#a369a3ad0a68e071ab6c6aba508695d42", null ],
    [ "UpdateSessionSettings", "class_s_e_mod_a_p_i_extensions_1_1_a_p_i_1_1_session_manager.html#a7fa11b441157b3b4a8bed789d50aef69", null ]
];