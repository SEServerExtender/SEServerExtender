var class_s_e_mod_a_p_i_internal_1_1_a_p_i_1_1_chat_1_1_chat_session =
[
    [ "Id", "class_s_e_mod_a_p_i_internal_1_1_a_p_i_1_1_chat_1_1_chat_session.html#a4dff80dea4ea97582682ac2d1e8642de", null ],
    [ "LastUpdatedTime", "class_s_e_mod_a_p_i_internal_1_1_a_p_i_1_1_chat_1_1_chat_session.html#a1dd4281e965d6288cfcd589c02c36451", null ],
    [ "Messages", "class_s_e_mod_a_p_i_internal_1_1_a_p_i_1_1_chat_1_1_chat_session.html#afaadec33e11a84223a04243681d90dea", null ]
];