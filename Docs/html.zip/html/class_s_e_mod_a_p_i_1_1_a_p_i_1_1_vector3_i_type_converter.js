var class_s_e_mod_a_p_i_1_1_a_p_i_1_1_vector3_i_type_converter =
[
    [ "CreateInstance", "class_s_e_mod_a_p_i_1_1_a_p_i_1_1_vector3_i_type_converter.html#ae86b8a8810b0d8d4a52b63b0bf2f4691", null ],
    [ "GetCreateInstanceSupported", "class_s_e_mod_a_p_i_1_1_a_p_i_1_1_vector3_i_type_converter.html#a59d303334fe1ba99117ef20261f4bd30", null ]
];