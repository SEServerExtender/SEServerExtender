var class_s_e_mod_a_p_i_1_1_a_p_i_1_1_definitions_1_1_cube_blocks_1_1_virtual_mass_definition =
[
    [ "VirtualMassDefinition", "class_s_e_mod_a_p_i_1_1_a_p_i_1_1_definitions_1_1_cube_blocks_1_1_virtual_mass_definition.html#a866dd073d1cb156ccb1efd346a61308b", null ],
    [ "GetSubTypeDefinition", "class_s_e_mod_a_p_i_1_1_a_p_i_1_1_definitions_1_1_cube_blocks_1_1_virtual_mass_definition.html#a8980177b0e02d51d4bf1d1e10d673554", null ],
    [ "MaxLightFalloff", "class_s_e_mod_a_p_i_1_1_a_p_i_1_1_definitions_1_1_cube_blocks_1_1_virtual_mass_definition.html#acf08afc9c8281d4f88302f8c1675a9a2", null ],
    [ "RequiredPowerInput", "class_s_e_mod_a_p_i_1_1_a_p_i_1_1_definitions_1_1_cube_blocks_1_1_virtual_mass_definition.html#adc8253f0e99dd170bce03779b6ffca23", null ]
];