var class_s_e_mod_a_p_i_extensions_1_1_a_p_i_1_1_structure_entry =
[
    [ "StructureEntry", "class_s_e_mod_a_p_i_extensions_1_1_a_p_i_1_1_structure_entry.html#ad81257134b2cdea5dc209fd34749fb27", null ],
    [ "color", "class_s_e_mod_a_p_i_extensions_1_1_a_p_i_1_1_structure_entry.html#aa26444b07d410cc191bc6f5cec0395e9", null ],
    [ "orientation", "class_s_e_mod_a_p_i_extensions_1_1_a_p_i_1_1_structure_entry.html#af4699f5150133ff39b5fa271f860afe5", null ],
    [ "subTypeName", "class_s_e_mod_a_p_i_extensions_1_1_a_p_i_1_1_structure_entry.html#aee8d0d7bf908f99a0e8cbd12e1ce4a03", null ],
    [ "type", "class_s_e_mod_a_p_i_extensions_1_1_a_p_i_1_1_structure_entry.html#a6641ee53eff0904209e829a0141ca721", null ],
    [ "useOrientation", "class_s_e_mod_a_p_i_extensions_1_1_a_p_i_1_1_structure_entry.html#a7025bea3ec17824cd9c25b2ee2aa93b5", null ],
    [ "useSubTypeName", "class_s_e_mod_a_p_i_extensions_1_1_a_p_i_1_1_structure_entry.html#a1fb9b11565af6e3ef6fea03ce80c8a62", null ]
];