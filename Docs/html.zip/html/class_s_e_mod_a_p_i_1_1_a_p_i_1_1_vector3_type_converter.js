var class_s_e_mod_a_p_i_1_1_a_p_i_1_1_vector3_type_converter =
[
    [ "CreateInstance", "class_s_e_mod_a_p_i_1_1_a_p_i_1_1_vector3_type_converter.html#af0a4303529e02ab767ee3d1bfaa9282d", null ],
    [ "GetCreateInstanceSupported", "class_s_e_mod_a_p_i_1_1_a_p_i_1_1_vector3_type_converter.html#a5d966bbd9cfe54ebc73f24f6e8f858cf", null ]
];