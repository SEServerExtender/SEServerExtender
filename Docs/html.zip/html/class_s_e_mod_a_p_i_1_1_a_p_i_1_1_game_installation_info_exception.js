var class_s_e_mod_a_p_i_1_1_a_p_i_1_1_game_installation_info_exception =
[
    [ "GameInstallationInfoException", "class_s_e_mod_a_p_i_1_1_a_p_i_1_1_game_installation_info_exception.html#a451462715027d089d7fd81ed397f5959", null ],
    [ "StateRepresentation", "class_s_e_mod_a_p_i_1_1_a_p_i_1_1_game_installation_info_exception.html#a82eeaa84fbce2623ff4624282c7d0e14", null ]
];