var class_s_e_mod_a_p_i_1_1_a_p_i_1_1_definitions_1_1_asteroid_clusters_config =
[
    [ "AsteroidClustersConfig", "class_s_e_mod_a_p_i_1_1_a_p_i_1_1_definitions_1_1_asteroid_clusters_config.html#a14341cf1c2a793a26cc826fb16d23915", null ],
    [ "CentralCluster", "class_s_e_mod_a_p_i_1_1_a_p_i_1_1_definitions_1_1_asteroid_clusters_config.html#a64ae0385f8575b0e92670d690f9c4960", null ],
    [ "Enabled", "class_s_e_mod_a_p_i_1_1_a_p_i_1_1_definitions_1_1_asteroid_clusters_config.html#a1396d51b0201917545dd74e86a721407", null ],
    [ "Offset", "class_s_e_mod_a_p_i_1_1_a_p_i_1_1_definitions_1_1_asteroid_clusters_config.html#ac051085dd537f6b32d9a3940af94fda5", null ]
];