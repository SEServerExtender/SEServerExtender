var class_s_e_mod_a_p_i_extensions_1_1_a_p_i_1_1_plugin_1_1_plugin_base =
[
    [ "PluginBase", "class_s_e_mod_a_p_i_extensions_1_1_a_p_i_1_1_plugin_1_1_plugin_base.html#afbc82e6f3fc1c32987ba6b097fea0a3d", null ],
    [ "Init", "class_s_e_mod_a_p_i_extensions_1_1_a_p_i_1_1_plugin_1_1_plugin_base.html#a6a9cb0b1d10befea89a6e9cc99b14e72", null ],
    [ "Shutdown", "class_s_e_mod_a_p_i_extensions_1_1_a_p_i_1_1_plugin_1_1_plugin_base.html#a4a84a753570c89c4277fd9606ce577d6", null ],
    [ "Update", "class_s_e_mod_a_p_i_extensions_1_1_a_p_i_1_1_plugin_1_1_plugin_base.html#a165742be590b2135a072505cadf613e7", null ],
    [ "m_name", "class_s_e_mod_a_p_i_extensions_1_1_a_p_i_1_1_plugin_1_1_plugin_base.html#a32751278d9c761b57c05628fa574c7a0", null ],
    [ "m_pluginId", "class_s_e_mod_a_p_i_extensions_1_1_a_p_i_1_1_plugin_1_1_plugin_base.html#afd2c859a8d641a5bddd08c4a12599c4b", null ],
    [ "m_version", "class_s_e_mod_a_p_i_extensions_1_1_a_p_i_1_1_plugin_1_1_plugin_base.html#ad91c7924b2029c34935d20198f576f5c", null ],
    [ "Id", "class_s_e_mod_a_p_i_extensions_1_1_a_p_i_1_1_plugin_1_1_plugin_base.html#abe601fc6cecfc77161010bc2aaa9dd4e", null ],
    [ "Name", "class_s_e_mod_a_p_i_extensions_1_1_a_p_i_1_1_plugin_1_1_plugin_base.html#a40bef7b479d187395793f0c07e4a255c", null ],
    [ "Version", "class_s_e_mod_a_p_i_extensions_1_1_a_p_i_1_1_plugin_1_1_plugin_base.html#a0836e33123f84aa0bb535f83092f8369", null ]
];