var class_s_e_mod_a_p_i_internal_1_1_a_p_i_1_1_common_1_1_entity_event_manager =
[
    [ "EntityEvent", "struct_s_e_mod_a_p_i_internal_1_1_a_p_i_1_1_common_1_1_entity_event_manager_1_1_entity_event.html", "struct_s_e_mod_a_p_i_internal_1_1_a_p_i_1_1_common_1_1_entity_event_manager_1_1_entity_event" ],
    [ "EntityEventType", "class_s_e_mod_a_p_i_internal_1_1_a_p_i_1_1_common_1_1_entity_event_manager.html#aa65a6a6bb031451b20a68dcd27f5d442", [
      [ "OnPlayerJoined", "class_s_e_mod_a_p_i_internal_1_1_a_p_i_1_1_common_1_1_entity_event_manager.html#aa65a6a6bb031451b20a68dcd27f5d442aadfe5450ff3d5ad4ebbea6a317a11ea8", null ],
      [ "OnPlayerLeft", "class_s_e_mod_a_p_i_internal_1_1_a_p_i_1_1_common_1_1_entity_event_manager.html#aa65a6a6bb031451b20a68dcd27f5d442a494d3ea1c26c0693b907a1f803bd3e2b", null ],
      [ "OnPlayerWorldSent", "class_s_e_mod_a_p_i_internal_1_1_a_p_i_1_1_common_1_1_entity_event_manager.html#aa65a6a6bb031451b20a68dcd27f5d442a28ae59a69f23a43f6c940fd58ecb7464", null ],
      [ "OnBaseEntityMoved", "class_s_e_mod_a_p_i_internal_1_1_a_p_i_1_1_common_1_1_entity_event_manager.html#aa65a6a6bb031451b20a68dcd27f5d442a918ed9cc05406679bdd43145402e6c3c", null ],
      [ "OnBaseEntityCreated", "class_s_e_mod_a_p_i_internal_1_1_a_p_i_1_1_common_1_1_entity_event_manager.html#aa65a6a6bb031451b20a68dcd27f5d442a558d422e02baa6c1e3a78496d52e2f9e", null ],
      [ "OnBaseEntityDeleted", "class_s_e_mod_a_p_i_internal_1_1_a_p_i_1_1_common_1_1_entity_event_manager.html#aa65a6a6bb031451b20a68dcd27f5d442a63a19c7a28f7689e520c33af7a47bcc2", null ],
      [ "OnCubeGridMoved", "class_s_e_mod_a_p_i_internal_1_1_a_p_i_1_1_common_1_1_entity_event_manager.html#aa65a6a6bb031451b20a68dcd27f5d442af42b91e58a333678537ce0e7fd2ba3e7", null ],
      [ "OnCubeGridCreated", "class_s_e_mod_a_p_i_internal_1_1_a_p_i_1_1_common_1_1_entity_event_manager.html#aa65a6a6bb031451b20a68dcd27f5d442a97bed8f6e17fae50fa80c42b3ed7442a", null ],
      [ "OnCubeGridDeleted", "class_s_e_mod_a_p_i_internal_1_1_a_p_i_1_1_common_1_1_entity_event_manager.html#aa65a6a6bb031451b20a68dcd27f5d442a351496d9ba86a8e0465ec75da67df9a2", null ],
      [ "OnCubeGridLoaded", "class_s_e_mod_a_p_i_internal_1_1_a_p_i_1_1_common_1_1_entity_event_manager.html#aa65a6a6bb031451b20a68dcd27f5d442a4d2e46f2cdaacff6c15ddaf859c7722b", null ],
      [ "OnCubeBlockCreated", "class_s_e_mod_a_p_i_internal_1_1_a_p_i_1_1_common_1_1_entity_event_manager.html#aa65a6a6bb031451b20a68dcd27f5d442ae31f5f7fc074fad3de5852b3d2cfa80b", null ],
      [ "OnCubeBlockDeleted", "class_s_e_mod_a_p_i_internal_1_1_a_p_i_1_1_common_1_1_entity_event_manager.html#aa65a6a6bb031451b20a68dcd27f5d442a3382a1fa4559d1bd751667033e284dfc", null ],
      [ "OnCharacterMoved", "class_s_e_mod_a_p_i_internal_1_1_a_p_i_1_1_common_1_1_entity_event_manager.html#aa65a6a6bb031451b20a68dcd27f5d442a47fa9a5b0106f2e704dc848ce0ea5048", null ],
      [ "OnCharacterCreated", "class_s_e_mod_a_p_i_internal_1_1_a_p_i_1_1_common_1_1_entity_event_manager.html#aa65a6a6bb031451b20a68dcd27f5d442a16899a1ddc7eb0aa45228fb17d848aa0", null ],
      [ "OnCharacterDeleted", "class_s_e_mod_a_p_i_internal_1_1_a_p_i_1_1_common_1_1_entity_event_manager.html#aa65a6a6bb031451b20a68dcd27f5d442a9edca8d748a67867c14b5601d1b33e4b", null ],
      [ "OnSectorSaved", "class_s_e_mod_a_p_i_internal_1_1_a_p_i_1_1_common_1_1_entity_event_manager.html#aa65a6a6bb031451b20a68dcd27f5d442ad3f7056dc7ae77367bf4a27b80b146a5", null ]
    ] ],
    [ "EntityEventManager", "class_s_e_mod_a_p_i_internal_1_1_a_p_i_1_1_common_1_1_entity_event_manager.html#a8424dd158948084e1cab9a953af71e8c", null ],
    [ "AddEvent", "class_s_e_mod_a_p_i_internal_1_1_a_p_i_1_1_common_1_1_entity_event_manager.html#a5c3fd2df12e472aa0d422bf01a3174be", null ],
    [ "ClearEvents", "class_s_e_mod_a_p_i_internal_1_1_a_p_i_1_1_common_1_1_entity_event_manager.html#afe95317e730b63b607da32fc3c4d03e2", null ],
    [ "EntityEvents", "class_s_e_mod_a_p_i_internal_1_1_a_p_i_1_1_common_1_1_entity_event_manager.html#a5c177cfe72dd6ffd7efa00a511e9949f", null ],
    [ "ResourceLocked", "class_s_e_mod_a_p_i_internal_1_1_a_p_i_1_1_common_1_1_entity_event_manager.html#a198e039578d480d7167fa66ea0102bde", null ]
];