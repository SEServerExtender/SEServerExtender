var class_s_e_mod_a_p_i_1_1_a_p_i_1_1_definitions_1_1_voxel_materials_definition =
[
    [ "VoxelMaterialsDefinition", "class_s_e_mod_a_p_i_1_1_a_p_i_1_1_definitions_1_1_voxel_materials_definition.html#a1dea3e91d9b9fa7f9bf795c53bcaa298", null ],
    [ "GetNameFrom", "class_s_e_mod_a_p_i_1_1_a_p_i_1_1_definitions_1_1_voxel_materials_definition.html#ae8d9eee872a3a6f3d9771bb06aa42b7d", null ],
    [ "CanBeHarvested", "class_s_e_mod_a_p_i_1_1_a_p_i_1_1_definitions_1_1_voxel_materials_definition.html#a74b2cf6f25a51fd124bb1a1059ec93f4", null ],
    [ "DamageRatio", "class_s_e_mod_a_p_i_1_1_a_p_i_1_1_definitions_1_1_voxel_materials_definition.html#aa3a8c1c5a7903f0c46683d45fb156232", null ],
    [ "IsRare", "class_s_e_mod_a_p_i_1_1_a_p_i_1_1_definitions_1_1_voxel_materials_definition.html#ad3b1013325d9adcae0eaaeff01335fb7", null ],
    [ "MinedOre", "class_s_e_mod_a_p_i_1_1_a_p_i_1_1_definitions_1_1_voxel_materials_definition.html#adb95b0d76eda609ba1b04b70aae30cde", null ],
    [ "MinedOreRatio", "class_s_e_mod_a_p_i_1_1_a_p_i_1_1_definitions_1_1_voxel_materials_definition.html#a0668415154e0fc85e6518ee1f62f652f", null ],
    [ "Name", "class_s_e_mod_a_p_i_1_1_a_p_i_1_1_definitions_1_1_voxel_materials_definition.html#a5b65e59d2bc22c11460f9f532502ef15", null ],
    [ "SpecularPower", "class_s_e_mod_a_p_i_1_1_a_p_i_1_1_definitions_1_1_voxel_materials_definition.html#a4403f74368a1ad960e2a95426d25b1d0", null ],
    [ "SpecularShininess", "class_s_e_mod_a_p_i_1_1_a_p_i_1_1_definitions_1_1_voxel_materials_definition.html#abe450a57b8ecb999cea3452a3e053c56", null ],
    [ "UseTwoTextures", "class_s_e_mod_a_p_i_1_1_a_p_i_1_1_definitions_1_1_voxel_materials_definition.html#adda5239aec923eee766a8f11bd2cbbec", null ]
];