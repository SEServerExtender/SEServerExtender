var class_s_e_mod_a_p_i_internal_1_1_a_p_i_1_1_common_1_1_world_manager =
[
    [ "WorldManager", "class_s_e_mod_a_p_i_internal_1_1_a_p_i_1_1_common_1_1_world_manager.html#ac892a3a4dcb3d1723e9125a691bf901d", null ],
    [ "AsynchronousSaveWorld", "class_s_e_mod_a_p_i_internal_1_1_a_p_i_1_1_common_1_1_world_manager.html#aedbf944c3d389c264409a0f5ac407727", null ],
    [ "ClearSpawnTimers", "class_s_e_mod_a_p_i_internal_1_1_a_p_i_1_1_common_1_1_world_manager.html#ab5767f91ba71c52531f4f20fc3321a26", null ],
    [ "OnWorldSaved", "class_s_e_mod_a_p_i_internal_1_1_a_p_i_1_1_common_1_1_world_manager.html#a1da5f2acd6fb682a9c78bdee56b9785f", null ],
    [ "SaveWorld", "class_s_e_mod_a_p_i_internal_1_1_a_p_i_1_1_common_1_1_world_manager.html#a9fd649f276a7affc6815b4ff4c7170ef", null ],
    [ "BackingObject", "class_s_e_mod_a_p_i_internal_1_1_a_p_i_1_1_common_1_1_world_manager.html#a3e0ebff03583feb3fcaf468afe953d93", null ],
    [ "Checkpoint", "class_s_e_mod_a_p_i_internal_1_1_a_p_i_1_1_common_1_1_world_manager.html#a92de2862f50751be7595a9544ce8949c", null ],
    [ "IsWorldSaving", "class_s_e_mod_a_p_i_internal_1_1_a_p_i_1_1_common_1_1_world_manager.html#abce7ad787a8bc3ea87488960b349eaca", null ],
    [ "Name", "class_s_e_mod_a_p_i_internal_1_1_a_p_i_1_1_common_1_1_world_manager.html#a3feed6ffd8df27368f298458037771a1", null ],
    [ "Sector", "class_s_e_mod_a_p_i_internal_1_1_a_p_i_1_1_common_1_1_world_manager.html#ae676836d6b820b609b620e6a5be3bc7a", null ],
    [ "SessionSettings", "class_s_e_mod_a_p_i_internal_1_1_a_p_i_1_1_common_1_1_world_manager.html#a061af12cd1b9aa6d2d8f6ad12bf0ef9e", null ],
    [ "WorldSaved", "class_s_e_mod_a_p_i_internal_1_1_a_p_i_1_1_common_1_1_world_manager.html#a74564bc7a82b868c9d0ae9ce2832f4b5", null ]
];